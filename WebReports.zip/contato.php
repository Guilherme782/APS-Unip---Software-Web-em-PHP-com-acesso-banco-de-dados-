<?php
    session_start();
    @$u=$_SESSION['nick'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>HTML Form to Google Sheets - Pure Coding</title>
</head>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">

</head>

<body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <i class="fa d-inline fa-lg fa-stop-circle"></i>
        <b> WEB REPORTS</b>
      </a> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar10">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar10">
        <ul class="navbar-nav ml-auto">
          <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="inicio.php">Painel</a> </li>';}?>
          <li class="nav-item"> <a class="nav-link" href="index.php">Inicio</a> </li>
          <li class="nav-item"> <a class="nav-link" href="politica.php">Politica</a> </li>
          <li class="nav-item"> <a class="nav-link" href="parceiros.php">Parceiros</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contato.php">Contato</a> </li>
         <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="destroi.php">Sair</a> </li>';}?>
        </ul> <a class="btn navbar-btn ml-md-2 text-body btn-info" href="ajudar.php">Ajudar</a>
      </div>
    </div>
  </nav>
  <div class="py-0" >
    <div class="container-fluid" >
       <div class="row text-center" style="	background-image: url(&quot;banner2.jpg&quot;);	background-position: left center;	background-size: 100%;	background-repeat: no-repeat;" >
        <div class="text-center p-15 col-lg-5" style="height: 600px;">
            
            <br>
            <h3>Entre em contato conosco!</h3>

         <div class="container py-3 text-left">
        <div class="row">
            <div class="col-lg-16 col-md-15 mx-auto shadow border bg-white p-20 rounded">
                <form name="google-sheet">
                    <div id="form_alerts"></div>
                    <div class="form-group mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" id="nome" name="nome" class="form-control" placeholder="Digite seu nome" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="Digite o seu Email" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="mensagem" class="form-label">Mensagem</label>
                        <textarea id="mensagem" name="mensagem" class="form-control" placeholder="Escreva a sua mensagem" rows="5" required></textarea>
                    </div>
                    <div>
                        <button class="btn btn-primary me-2" type="submit">Enviar mensagem</button>
                        <button class="btn btn-danger" type="reset">Limpar dados</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const scriptURL = 'https://script.google.com/macros/s/AKfycby-HKWWxeRXl0d8t4J3MeJeNpcWh2sXMZcYm5Sezoswv_DLyAtK-nrkKR2UebrHUP6H/exec'
        const form = document.forms['google-sheet']
        
        form.addEventListener('submit', e => {
            e.preventDefault()
            fetch(scriptURL, { method: 'POST', body: new FormData(form)})
            .then(response => $("#form_alerts").html("<div class='alert alert-success'>A Mensagem foi enviada com Sucesso!.</div>"))
            .catch(error => $("#form_alerts").html("<div class='alert alert-danger'>A Mensagem não foi Enviada!</div>"))
        })
    </script>
</body>
</html>
