<?php
require 'banco.php';
//Acompanha os erros de validação
$Erro = "";
// Processar so quando tenha uma chamada post
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome="";
    $cpf="";
    $nascimento="";
    $genero="";
    $email="";
    $email_r=$_POST['email2'];
    $telefone="";
    $telefone2="";
    
    $endereco = "";
    $pais = "";
    $estado = "";
    $cidade = "";
    $bairro = "";
    $referencia = "";
    
    $user = "";
    $senha = "";
    $nk = "";
    

    if (!empty($_POST)) {
        $validacao = True;
        
        //validação se login
        if (!empty($_POST['senha'])) {
            if($_POST['senha']==$_POST['senha2']){
               $senha = $_POST['senha'];  
            }else{
                $Erro = 'As senhas não conferem!';
                $validacao = False;                
            }
        } else {
            $Erro = 'A Senha não pode ser Nula!';
            $validacao = False;
        } 
        
         if (!empty($_POST['usuario'])) {
                $user = $_POST['usuario'];  
                 
                $pdo = Banco::conectar();
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql =  'SELECT Nick FROM login WHERE Nick = "'.$user.'"';
                
                        foreach($pdo->query($sql)as $row)
                        {
                          $nk =  $row['Nick'];
                        }

                if($nk==$user){
                    $Erro = 'O Usuário já existe!';
                    $validacao = False;  
                }
             Banco::desconectar();
             

             
        } else {
            $Erro = 'O Usuário não pode ser Nulo!';
            $validacao = False;
        }   

        
        
        //Validação de localização
        if (!empty($_POST['referencia'])) {
            $referencia = $_POST['referencia'];
        } else {
            $referencia = null;
        }   
        
        if (!empty($_POST['bairro'])) {
            $bairro = $_POST['bairro'];
        } else {
            $Erro = 'O Bairro não pode ser Nulo!';
            $validacao = False;
        } 
        
        if (!empty($_POST['cidade'])) {
            $cidade = $_POST['cidade'];
        } else {
            $Erro = 'A Cidade não pode ser Nula!';
            $validacao = False;
        } 
        
        if (!empty($_POST['estado'])) {
            $estado = $_POST['estado'];
        } else {
            $Erro = 'O Estado não pode ser Nulo!';
            $validacao = False;
        } 
        
        if (!empty($_POST['pais'])) {
            $pais = $_POST['pais'];
        } else {
            $Erro = 'O País não pode ser Nulo!';
            $validacao = False;
        } 

        if (!empty($_POST['endereco'])) {
            $endereco = $_POST['endereco'];
        } else {
            $Erro = 'O Endereço não pode ser Nulo!';
            $validacao = False;
        } 
        
        //cadastro do usuário
        
        if (!empty($_POST['telefone2'])) {
            $telefone2 = $_POST['telefone2'];
        } else {
            $telefone2 = null;
        }        
        
        if (!empty($_POST['telefone'])) {
            $telefone = $_POST['telefone'];
        } else {
            $telefone = null;
        } 

        if (!empty($_POST['email'])) {
            $email = $_POST['email'];
            if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $Erro = 'Por favor digite um endereço de email válido!';
                $validacao = False;
            }else if($_POST['email']!=$_POST['email2']){
            $Erro = 'Os Emails não são iguais!';
            $validacao = False;               
            }
        } else {
            $Erro = 'O email não pode ser Nulo!';
            $validacao = False;
        }

        if (!empty($_POST['genero'])) {
            $genero = $_POST['genero'];
        } else {
            $Erro = 'O Gênero não pode ser Nulo!';
            $validacao = False;
        } 
        
         if (!empty($_POST['nascimento'])) {
            $nascimento = $_POST['nascimento'];
        } else {
            $Erro = 'A data de Nascimento não pode ser Nula!';
            $validacao = False;
        }   
         if (!empty($_POST['cpf'])) {
            $cpf = $_POST['cpf'];
        } else {
            $Erro = 'O CPF não pode ser Nulo!';
            $validacao = False;
        }       

        if (!empty($_POST['nome'])) {
            $nome = $_POST['nome'];
        } else {
            $Erro = 'O Nome não pode ser Nulo!';
            $validacao = False;
        }        
               
        





        
     
        
 
        

        
    }
// $validacao = False;
//Inserindo no Banco:
    if ($validacao) {
        $pdo = Banco::conectar();
        
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //Grava a tabela usuario
        $sql = "INSERT INTO usuario (nome, cpf, nascimento, email, genero) VALUES(?,?,?,?,?)";
        $q = $pdo->prepare($sql);
        $q->execute(array($nome, $cpf, $nascimento, $email, $genero));
        ///busca id
        if(!empty($cpf)){
                $sql =  'SELECT idUsuario FROM usuario WHERE cpf = "'.$cpf.'"';
            
                        foreach($pdo->query($sql)as $row)
                        {
                          $id = $row['idUsuario'];
                        }
        
        //Grava a tabela local
        $sql = "INSERT INTO local (pais, estado, cidade, bairro, endereco,p_referencia,Usuario_idUsuario) VALUES(?,?,?,?,?,?,?)";
        $q = $pdo->prepare($sql);
        $q->execute(array($pais, $estado, $cidade, $bairro, $endereco, $referencia,$id));
  
        //Grava a tabela Login
        $sql = "INSERT INTO login (Nick, senha, qd_login, Usuario_idUsuario) VALUES(?,?,?,?)";
        $q = $pdo->prepare($sql);
        $q->execute(array($user, $senha, "ativo", $id));
        
        //Grava a o contato
        $sql = "INSERT INTO contatos (telefone, telefone_2, Usuario_idUsuario) VALUES(?,?,?)";
        $q = $pdo->prepare($sql);
        $q->execute(array($telefone, $telefone2, $id));    
        }
        
        
        Banco::desconectar();
        echo "<script>alert('Cadastrado com Sucesso!');window.location.href = 'index.php';</script>";
        //header("Location: index.php");
    }
}

?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">
<script type="text/javascript">   

</script> 
</head>

<body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <i class="fa d-inline fa-lg fa-stop-circle"></i>
        <b> WEB REPORTS</b>
      </a> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar10">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar10">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="index.php">Inicio</a> </li>
          <li class="nav-item"> <a class="nav-link" href="politica.php">Politica</a> </li>
          <li class="nav-item"> <a class="nav-link" href="parceiros.php">Parceiros</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contato.php">Contato</a> </li>
        </ul> <a class="btn navbar-btn ml-md-2 text-body btn-info" href="ajudar.php">Ajudar</a>
      </div>
    </div>
  </nav>
  <div class="py-0" >
    <div class="container-fluid" >
        
              <!-- Modal body Cadastro-->
      <div class="modal-body">
      <center>
	     <h2>Cadastro de Usuário</h2>
          <h5 class="mb-1">Seus danos são mantidos em sigilo.</h5>
          <font color="red" size="14"><?php echo $Erro?></font>
      </center>
        <div class="p-1 col" >
  
          <form class="form-horizontal" action="cadastro.php" method="post">
			<div class="container" >
				<div class="row border border-dark p-2" >
                    <div class="form-group col-1" style="text-align: right"><h4>Nome:</h4></div>
					<div class="form-group col-11">
                        <input type="text" value="<?php echo @$nome; ?>" class="form-control"  name="nome"  placeholder="Digite seu Nome completo">
                    </div>
                    <div class="form-group col-1" style="text-align: right"><h4>CPF:</h4></div>
                    <div class="form-group col-4">
                        <input type="text" value="<?php echo @$cpf; ?>" class="form-control" maxlength="14" name="cpf" pattern="(\d{3}\.?\d{3}\.?\d{3}-?\d{2})|(\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2})" placeholder="000.000.000-00">
                    </div>
                     <div class="form-group col-2" style="text-align: right"><h4>Nascimento:</h4></div>
                    <div class="form-group col-2">
                        <input type="text" value="<?php echo @$nascimento; ?>" class="form-control" name="nascimento"   placeholder="0000-00-00">
                    </div>
                    <div class="form-group col-1" style="text-align: right"><h4>Gênero:</h4></div>
                    <div class="form-group col-2">
                        <select name="genero" style="font-size: 22px">
                            <option value="<?php echo @$genero; ?>"><?php echo @$genero; ?></option><option value="F">Feminino</option><option value="M">Masculino</option>
                        </select>
                    </div>
                     <div class="form-group col-2" style="text-align: right"><h4>Email:</h4></div>                    
					<div class="form-group col-7">
                        <input type="email" value="<?php echo @$email; ?>" class="form-control" name="email"  placeholder="Digite seu Email">
                    </div>
                     <div class="form-group col-1" style="text-align: right"><h4>Telefone:</h4></div>                    
					<div class="form-group col-2">
                        <input type="text" value="<?php echo @$telefone; ?>" maxlength="11" class="form-control" name="telefone"  placeholder="Telefone">
                    </div>
                     <div class="form-group col-2" style="text-align: right"><h4>Repita o Email:</h4></div>                    
					<div class="form-group col-7">
                        <input type="email" value="<?php echo @$email_r; ?>" class="form-control" name="email2"  placeholder="Repita seu Email">
                    </div>
                     <div class="form-group col-1" style="text-align: right"><h4>Recado:</h4></div>                    
					<div class="form-group col-2">
                        <input type="text" value="<?php echo @$telefone2; ?>" class="form-control" maxlength="11" name="telefone2"  placeholder="Recado">
                    </div>				
				</div>
                <br>
				<div class="row border border-dark p-2" >
                    <div class="form-group col-2" style="text-align: right"><h4>Endereço:</h4></div>                    
					<div class="form-group col-10">
                        <input type="text" value="<?php echo @$endereco; ?>" class="form-control" name="endereco" placeholder="Digite seu Endereço">
                    </div>
                    <div class="form-group col-1" style="text-align: right"><h4>País:</h4></div>                    
					<div class="form-group col-3">
                        <input type="text" value="<?php echo @$pais; ?>" class="form-control" name="pais" placeholder="País">
                    </div>
                    <div class="form-group col-1" style="text-align: right"><h4>Estado:</h4></div>                    
					<div class="form-group col-3">
                        <input type="text" value="<?php echo @$estado; ?>" class="form-control" name="estado" placeholder="Estado">
                    </div>                   
                    <div class="form-group col-1" style="text-align: right"><h4>Cidade:</h4></div>                    
					<div class="form-group col-3">
                        <input type="text" value="<?php echo @$cidade; ?>" class="form-control" name="cidade" placeholder="Cidade">
                    </div>                 
                    <div class="form-group col-1" style="text-align: right"><h4>Bairro:</h4></div>                    
					<div class="form-group col-3">
                        <input type="text" value="<?php echo @$bairro; ?>" class="form-control" name="bairro" placeholder="Bairro">
                    </div>                 
                    <div class="form-group col-2" style="text-align: right"><h4> Complemento: </h4></div>                    
					<div class="form-group col-3">
                        <input type="text" value="<?php echo @$referencia; ?>" class="form-control"  name="referencia" placeholder="Referência">
                    </div>                               
                    <div class="form-group col-1" style="text-align: right"><h4> Cep: </h4></div>                    
					<div class="form-group col-2">
                        <input type="text" maxlength="8" value="<?php echo @$cep; ?>" class="form-control"  name="cep" placeholder="CEP">
                    </div> 								
				</div>
                
                 <br>
				<div class="row border border-dark p-2" >
                    <div class="form-group col-2" style="text-align: right"><h4>Usuário:</h4></div>                    
					<div class="form-group col-10">
                        <input type="text" value="<?php echo @$user; ?>" class="form-control" maxlength="40" name="usuario" placeholder="Digite o seu nome de usuário">
                    </div>
                    <div class="form-group col-2" style="text-align: right"><h4>Senha:</h4></div>                    
					<div class="form-group col-10">
                        <input type="password" value="" maxlength="30" class="form-control" name="senha" placeholder="Senha">
                    </div>                               
                    <div class="form-group col-2" style="text-align: right"><h4>Repita:</h4></div>                    
					<div class="form-group col-10">
                        <input type="password" value="" maxlength="30" class="form-control" name="senha2" placeholder="Repita a Senha">
                    </div> 								
				</div>

			</div>
		
              
              
      <!-- Modal footer -->
      <div class="modal-footer">
            <!--<button type="button" class="btn btn-secondary mx-3" data-toggle="modal" data-target="#mymodal_conf">-->
            <button type="submit" class="btn btn-secondary mx-0"> Cadastrar</button>
        <button type="button" class="btn btn-primary mx-4">Voltar</button>
      </div>
      </form>
		  
        </div>
		
      </div>
        
    </div>
  </div>

  
    
    
    
    
    
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous" style=""></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>