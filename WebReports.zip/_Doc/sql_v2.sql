-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema webreports
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema webreports
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `webreports` DEFAULT CHARACTER SET utf8 ;
USE `webreports` ;

-- -----------------------------------------------------
-- Table `webreports`.`Usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `webreports`.`Usuario` (
  `idUsuario` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `cpf` VARCHAR(15) NOT NULL,
  `nascimento` DATE NOT NULL,
  `email` VARCHAR(200) NOT NULL,
  `genero` VARCHAR(2) NOT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE,
  UNIQUE INDEX `cpf_UNIQUE` (`cpf` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `webreports`.`Local`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `webreports`.`Local` (
  `idLocal` INT NOT NULL AUTO_INCREMENT,
  `pais` VARCHAR(45) NOT NULL,
  `estado` VARCHAR(45) NOT NULL,
  `cidade` VARCHAR(45) NOT NULL,
  `bairro` VARCHAR(45) NOT NULL,
  `endereco` VARCHAR(45) NOT NULL,
  `cep` INT NULL,
  `p_referencia` VARCHAR(145) NULL,
  `Usuario_idUsuario` INT NOT NULL,
  PRIMARY KEY (`idLocal`, `Usuario_idUsuario`),
  INDEX `fk_Local_Usuario_idx` (`Usuario_idUsuario` ASC) VISIBLE,
  CONSTRAINT `fk_Local_Usuario`
    FOREIGN KEY (`Usuario_idUsuario`)
    REFERENCES `webreports`.`Usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `webreports`.`Login`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `webreports`.`Login` (
  `idLogin` INT NOT NULL AUTO_INCREMENT,
  `Nick` VARCHAR(45) NOT NULL,
  `senha` VARCHAR(45) NOT NULL,
  `qd_login` VARCHAR(45) NULL,
  `Usuario_idUsuario` INT NOT NULL,
  PRIMARY KEY (`idLogin`, `Usuario_idUsuario`),
  INDEX `fk_Login_Usuario1_idx` (`Usuario_idUsuario` ASC) VISIBLE,
  CONSTRAINT `fk_Login_Usuario1`
    FOREIGN KEY (`Usuario_idUsuario`)
    REFERENCES `webreports`.`Usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `webreports`.`Contatos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `webreports`.`Contatos` (
  `idContatos` INT NOT NULL AUTO_INCREMENT,
  `Telefone` INT(11) NOT NULL,
  `Telefone_2` INT(15) NULL,
  `Facebook` VARCHAR(45) NULL,
  `twitter` VARCHAR(45) NULL,
  `link_pessoasl` VARCHAR(45) NULL,
  `Usuario_idUsuario` INT NOT NULL,
  PRIMARY KEY (`idContatos`, `Usuario_idUsuario`),
  INDEX `fk_Contatos_Usuario1_idx` (`Usuario_idUsuario` ASC) VISIBLE,
  CONSTRAINT `fk_Contatos_Usuario1`
    FOREIGN KEY (`Usuario_idUsuario`)
    REFERENCES `webreports`.`Usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `webreports`.`Lista_Afinidade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `webreports`.`Lista_Afinidade` (
  `idLista_Afinidade` INT NOT NULL AUTO_INCREMENT,
  `Violencia` TINYINT NULL,
  `abuso` TINYINT NULL,
  `xenofobia` TINYINT NULL,
  `agressao` TINYINT NULL,
  `Usuario_idUsuario` INT NOT NULL,
  PRIMARY KEY (`idLista_Afinidade`, `Usuario_idUsuario`),
  INDEX `fk_Lista_Afinidade_Usuario1_idx` (`Usuario_idUsuario` ASC) VISIBLE,
  CONSTRAINT `fk_Lista_Afinidade_Usuario1`
    FOREIGN KEY (`Usuario_idUsuario`)
    REFERENCES `webreports`.`Usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `webreports`.`Relatos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `webreports`.`Relatos` (
  `idRelatos` INT NOT NULL AUTO_INCREMENT,
  `Nink` VARCHAR(45) NOT NULL,
  `tipo` VARCHAR(45) NULL,
  `data` DATE NULL,
  `comentario` VARCHAR(900) NOT NULL,
  `Usuario_idUsuario` INT NOT NULL,
  PRIMARY KEY (`idRelatos`, `Usuario_idUsuario`),
  INDEX `fk_Relatos_Usuario1_idx` (`Usuario_idUsuario` ASC) VISIBLE,
  CONSTRAINT `fk_Relatos_Usuario1`
    FOREIGN KEY (`Usuario_idUsuario`)
    REFERENCES `webreports`.`Usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `webreports`.`comentarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `webreports`.`comentarios` (
  `idcomentarios` INT NOT NULL AUTO_INCREMENT,
  `Nink` VARCHAR(45) NOT NULL,
  `comentario` VARCHAR(845) NOT NULL,
  `nota` VARCHAR(45) NOT NULL,
  `Relatos_idRelatos` INT NOT NULL,
  `Relatos_Usuario_idUsuario` INT NOT NULL,
  PRIMARY KEY (`idcomentarios`, `Relatos_idRelatos`, `Relatos_Usuario_idUsuario`),
  INDEX `fk_comentarios_Relatos1_idx` (`Relatos_idRelatos` ASC, `Relatos_Usuario_idUsuario` ASC) VISIBLE,
  CONSTRAINT `fk_comentarios_Relatos1`
    FOREIGN KEY (`Relatos_idRelatos` , `Relatos_Usuario_idUsuario`)
    REFERENCES `webreports`.`Relatos` (`idRelatos` , `Usuario_idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

/*
!Para testes seguem comandos abaixo

insert into usuario values(null,"Admin",112323323,"2021-04-01","admin@admin.com","M");
insert into local values(null,"Brasil","Goías","Aparecida de Goiânia","Buriti Sereno","Avenida Mal rondon",737473,"proximo ao muro de argila",12);
insert into contatos values(null,9445434,null,null,null,null,1);
insert into login values(null,"mara","1234","ativo",1);
SELECT Nick FROM login WHERE Nick = "mara";

SELECT idUsuario FROM usuario WHERE cpf = 11374;
*/