#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 10

struct aluno {
	int matricula;
	char nome[30];
	float n1,n2,n3;
};

typedef struct lista Lista;

struct lista{
	int qtd;
	struct aluno dados[MAX];
};

Lista *li;

Lista* cria_lista();
void libera_lista(Lista* li);
int tamanho_lista(Lista* li);
int lista_cheia(Lista* li);
int lista_vazia(Lista* li);
int insere_lista_inicio(Lista* li, struct aluno al);
int insere_lista_ordenada(Lista* li,struct aluno al);
int remove_lista_final(Lista* li);
int remove_lista_inicio(Lista* li);
int remove_lista(Lista* li, int mat);
int consulta_lista_pos(Lista* li, int pos, struct aluno *al);
int consulta_lista_matricula(Lista* li, int mat, struct aluno *al);

//fun��o de cria��o de lista
Lista* cria_lista(){
	Lista *li;
	li = (Lista*)malloc(sizeof(struct lista));
	if(li != NULL){
		li->qtd=0;
		return li;
	}
}
//fun��o de inser��o de dados na lista pelo inicio
int insere_lista_inicio(Lista* li, struct aluno al){
	if(li == NULL) return 0;
	if(lista_cheia(li)) return 0;
	int i;
	for(i=li->qtd-1;i>=0;i--){
		li->dados[i+1] = li->dados[i];
		li->dados[0] = al;
		li->qtd++;
		return 1;
	}
}
//fun��o que insere na lista de forma ORDENADA
int insere_lista_ordenada(Lista* li, struct aluno al){
	if(li == NULL) return 0;
	if(lista_cheia(li)) return 0;
	int k,i=0;
	while(i<li->qtd && li->dados[i].matricula<al.matricula){  //ordena o aluno pela matricula
		i++;
	}
	
	for(k=li->qtd;k>=i;k--){
		li->dados[k+1] = li->dados[k];
		li->dados[i] = al;
		li->qtd++;
		return 1;
	}
}
//remove elemento do final da lista
int remove_lista_final(Lista* li){
	if(li==NULL)
	return 0;
	if(li->qtd==0)
	return 0;
	li->qtd--;
	return 1;
}
//remove elemento do inicio da lista
int remove_lista_inicio(Lista* li){
	if(li==NULL)
	return 0;
	if(li->qtd==0)
	return 0;
	
	int k;
	for(k=0;k<li->qtd-1;k++){
		li->dados[k]=li->dados[k+1];
		li->qtd--;
		return 1;
	}
}
//remove o elemento de QUALQUER LUGAR da lista
int remove_lista(Lista* li, int mat){
	if(li==NULL) return 0;
	if(li->qtd==0) return 0;
	int k,i = 0;
	while(i<li->qtd && li->dados[i].matricula!=mat){
		i++;
	}
	if(i==li->qtd)//n�o achou
	return 0;
	
	for(k=i;k<li->qtd-1;k++){
		li->dados[k] = li->dados[k+1];
		li->qtd--;
		return 1;
	}
}
//Consultar lista pela posi��o inserida
int consulta_lista_pos(Lista* li, int pos, struct aluno *al){
	if(li==NULL||pos<=0||pos>li->qtd){
		return 0;
	}else{
		*al = li->dados[pos-1];
	}
}
//consulta lista pela matricula do aluno
int consulta_lista_matricula(Lista* li, int mat, struct aluno *al){
	if(li==NULL) return 0;
	int k,i=0;
	while(i<li->qtd && li->dados[i].matricula!=mat){
		i++;
	}
	if(i==li->qtd) return 0;
	*al = li->dados[i];
}

//apaga a lista
void libera_lista(Lista* li){
	free(li);
}
//retorna o tamanho da lista
int tamanho_lista(Lista* li){
	if(li==NULL){
		return -1;
	}else{
		return li->qtd;
	}
}
int lista_cheia(Lista* li){   //INT X = lista_cheia(li) ou  if(lista_cheia(li))
	if(li==NULL)
		return -1;
		return (li->qtd==MAX);
	
}
int lista_vazia(Lista* li){   //INT X = lista_vazia(li) ou  if(lista_vazia(li))
	if(li==NULL)
		return -1;
		return (li->qtd==0);
	
}


int main(){
	struct aluno dados_aluno;
	li = cria_lista();
	//libera_lista(li);
	//int x = insere_lista_inicio(li,dados_aluno);
	//int x = insere_lista_ordenada(li,dados_aluno);
	//int x = remove_lista_final(li);
	//int x = remove_lista_inicio(li);	
	//int x = remove_lista(li,matricula_aluno);	
	//int x = consulta_lista_pos(li,posicao,&dados_aluno);
	//int x = consulta_lista_matricula(li,mat,&dados_aluno);
	dados_aluno.matricula=1;
	strcpy(dados_aluno.nome,"Adeilson");
	dados_aluno.n1=8.5;
	dados_aluno.n2=9.0;
	dados_aluno.n3=9.9;
	
	int x = insere_lista_ordenada(li,dados_aluno);
	
	dados_aluno.matricula=2;
	strcpy(dados_aluno.nome,"Valesk");
	dados_aluno.n1=5;
	dados_aluno.n2=6;
	dados_aluno.n3=4;
	x = insere_lista_ordenada(li,dados_aluno);
	//recupera informa��o
	x = consulta_lista_pos(li,1,&dados_aluno);
	
	printf("Matricula: %d - Nome: %s ",dados_aluno.matricula,dados_aluno.nome);
	
	return 0;
}
