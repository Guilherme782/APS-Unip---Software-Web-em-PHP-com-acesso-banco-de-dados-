<?php
require 'banco.php';
//Acompanha os erros de validação
$Erro = "";
    session_start();
    @$u=$_SESSION['nick'];
    @$_id=$_SESSION['_id'];
    @$_nome=$_SESSION['_nome'];
    @$_genero=$_SESSION['_genero'];
    @$_cpf=$_SESSION['_cpf'];
    if(!@$u){
        header('Location: index.php');
    }



?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">
</head>

<body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <i class="fa d-inline fa-lg fa-stop-circle"></i>
        <b> WEB REPORTS</b>
      </a> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar10">
        <span class="navbar-toggler-icon"></span>
      </button>
      <font color="white" size="5">Logado como: 
        <?php echo @$u;?>
      </font>
      <div class="collapse navbar-collapse" id="navbar10">
        <ul class="navbar-nav ml-auto">
          <?php  if(@$u){echo '<li class="nav-item"--> <a class="nav-link" href="inicio.php">Painel</a> ';}?><li class="nav-item"> <a class="nav-link" href="index.php">Inicio</a> </li>
          <li class="nav-item"> <a class="nav-link" href="politica.php">Politica</a> </li>
          <li class="nav-item"> <a class="nav-link" href="parceiros.php">Parceiros</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contato.php">Contato</a> </li>
          <li class="nav-item"> <a class="nav-link" href="destroi.php">Sair</a> </li>
        </ul> <a class="btn navbar-btn ml-md-2 text-body btn-info" href="ajudar.php">Ajudar</a>
      </div>
    </div>
  </nav>
  <div class="container-fluid">
    <div class="row border p-0" style="height:100%">
      <div class="form-group col-2 bg-light">
        <div class="form-group row bg-info " style="text-align: ">
          <div class="form-group col-11 px-1 py-1 bg-light" style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/Others/architecture.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center center;" height="200">
          <img src="<?php if($_genero=='F'){echo 'f.png';}else{echo 'm.png';}?>" height="200">
          </div>
          <div class="form-group col-11 px-1 py-1 bg-light">aqui vem um menu<br><br>
              ID: <?php echo @$_id;?><br>
              CPF: <?php echo @$_cpf;?><br>
          
          </div>
        </div>
      </div>
      <div class="form-group col-8 " >
        <div class="row border p-0" style="height:50%">
         <div class="form-group px-3 py-1">
    		   <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" cols="120"></textarea>
           <button type="button" class="btn btn-secondary mx-1" >Postar </button>
           <button type="button" class="btn btn-info mx-1" >Apagar </button>
           <button type="button" class="btn btn-info mx-1" >Inserir </button>
           <button type="button" class="btn btn-info mx-1" >Restrições </button>
  		   </div>
       </div>
         <div class="row border p-0 px-2 py-1 bg-light" style="height:240%" >
           <h2>Bem vindo: <?php echo @$_nome;?></h2><br>
         <div class="form-group col-12 px-1 py-1 bg-light" style="height:75%;background-image: url('https://i0.wp.com/rjnoticias.com/wp-content/uploads/10530739_721826727890090_4032982850467291543_n-e1407369268647.png'); background-repeat: no-repeat; background-size: cover; background-position: center center;"></div>
          <div class="form-group col-12 px-1 py-1 bg-light" style="height:75%;background-image: url('https://miro.medium.com/max/800/1*A4csFYswe76QVeBSIIP-eQ.jpeg'); background-repeat: no-repeat; background-size: cover; background-position: center center;"></div>          
           
        </div>


      </div>
      <div class="form-group col-2  bg-light" >
        <div class="form-group row bg-info " style="height:200%">Pessoas Conectadas</div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous" style=""></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>