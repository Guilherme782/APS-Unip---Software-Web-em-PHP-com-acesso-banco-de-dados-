<?php

    session_start();
    @$u=$_SESSION['nick'];
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">

</head>

<body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <i class="fa d-inline fa-lg fa-stop-circle"></i>
        <b> WEB REPORTS</b>
      </a> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar10">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar10">
        <ul class="navbar-nav ml-auto">
          <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="inicio.php">Painel</a> </li>';}?>
          <li class="nav-item"> <a class="nav-link" href="index.php">Inicio</a> </li>
          <li class="nav-item"> <a class="nav-link" href="politica.php">Politica</a> </li>
          <li class="nav-item"> <a class="nav-link" href="parceiros.php">Parceiros</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contato.php">Contato</a> </li>
         <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="destroi.php">Sair</a> </li>';}?>
        </ul> <a class="btn navbar-btn ml-md-2 text-body btn-info" href="ajudar.php">Ajudar</a>
      </div>
    </div>
  </nav>
  <div class="py-0" >
    <div class="container-fluid" >
 
        <div class="text-center p-5 col-lg-12" style="height: 600px">
            Faça parte dessa iniciativa cujo objetivo é ajudar quem sofre<br>
         algum tipo de violência fisica, pisicoligica, atendados e afins<br>
            Precisamos de sua ajuda para chegar mais longe, seja financeira<br>
          para manuntenção de servidores e pessoal assim como ajuda de custo<br>
          a algum eventual caso que precise de uma interferência judiciaria ou <br>
          como voluntários(as). Sua participação é importante para a vida<br>
          de muitas pessaoas. Não fique de fora!<br><br>
            
           Seja um parceiro <a href="contato.php">Contato</a>

         </div>
      
    </div>
  </div>

  
    
    
    
    
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous" style=""></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
</body>

</html>