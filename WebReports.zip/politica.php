<?php 

    session_start();
    @$u=$_SESSION['nick'];

?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">

</head>

<body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <i class="fa d-inline fa-lg fa-stop-circle"></i>
        <b> WEB REPORTS</b>
      </a> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar10">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar10">
        <ul class="navbar-nav ml-auto">
          <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="inicio.php">Painel</a> </li>';}?>
          <li class="nav-item"> <a class="nav-link" href="index.php">Inicio</a> </li>
          <li class="nav-item"> <a class="nav-link" href="politica.php">Politica</a> </li>
          <li class="nav-item"> <a class="nav-link" href="parceiros.php">Parceiros</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contato.php">Contato</a> </li>
         <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="destroi.php">Sair</a> </li>';}?>
        </ul> <a class="btn navbar-btn ml-md-2 text-body btn-info" href="ajudar.php">Ajudar</a>
      </div>
    </div>
  </nav>
  <div class="py-0" >
    <div class="container-fluid" >
 
  <div class="py-2 border border-dark p-2 " >
      
            Politica do  Webreports<br><br>
      <p>A Pol&iacute;tica de Privacidade On-Line do site da <strong>Web Reports</strong> (https://www.webreports.com.br) foi criada para respeitar a LGPD (<a href="http://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/L13709.htm" target="_blank" rel="noopener">Lei Geral de Prote&ccedil;&atilde;o de Dados</a>) e afirmar o nosso compromisso com a seguran&ccedil;a e a privacidade das informa&ccedil;&otilde;es coletadas dos visitantes de nosso site. Esta pol&iacute;tica est&aacute; sujeita a eventuais atualiza&ccedil;&otilde;es e recomendamos que ela seja consultada periodicamente. Voc&ecirc; pode <a href="$site" target="_blank" rel="noopener">visitar nosso site</a> e conhecer nossos servi&ccedil;os e produtos, verificar nossas ofertas, ler artigos, obter informa&ccedil;&otilde;es e suporte sem precisar fornecer nenhuma informa&ccedil;&atilde;o pessoal. Mas, caso isso aconte&ccedil;a, esta pol&iacute;tica procura esclarecer como coletamos e tratamos seus dados pessoais.</p>
<p><br /><br /></p>
<h2>Como tratamos os dados</h2>
<ol>
<li>Qualquer informa&ccedil;&atilde;o fornecida pelos usu&aacute;rios ser&aacute; coletada e guardada de acordo com os padr&otilde;es atuais de seguran&ccedil;a e confiabilidade.</li>
<li>Utilizamos em nosso site o protocolo padr&atilde;o HTTPS que garante que todas as informa&ccedil;&otilde;es coletadas dos usu&aacute;rios trafeguem de forma segura, utilizando processo de criptografia padr&atilde;o da Internet.</li>
<li>As informa&ccedil;&otilde;es pessoais que nos forem fornecidas ser&atilde;o coletadas por meios legais. Essa coleta ter&aacute; o prop&oacute;sito de comunica&ccedil;&atilde;o comercial para que possamos vender nossos servi&ccedil;os, produtos, prestar suporte a atendimento sobre eles.</li>
<li>A menos que tenhamos determina&ccedil;&atilde;o legal ou judicial, as informa&ccedil;&otilde;es dos usu&aacute;rios jamais ser&atilde;o fornecidas a terceiros ou usadas para finalidades diferentes daquelas para as quais foram coletadas.</li>
<li>O acesso as informa&ccedil;&otilde;es coletadas est&aacute; restrito apenas aos gestores da <strong>Web Reports</strong> e manteremos a integridade das informa&ccedil;&otilde;es que nos forem fornecidas.</li>
<li>Eventualmente, poderemos utilizar cookies (*) para confirmar sua identidade, personalizar seu acesso e acompanhar a utiliza&ccedil;&atilde;o de nosso website visando o aprimoramento de sua navega&ccedil;&atilde;o e funcionalidade.</li>
<li>Colocamos &agrave; disposi&ccedil;&atilde;o de nossos usu&aacute;rios, canais de atendimento ao cliente, para esclarecer qualquer d&uacute;vida que possa surgir referente aos seus dados. Estes canais podem ser acionados atrav&eacute;s do e-mail <a href="mailto:webreports@gmail.com">webreports@gmail.com</a>.</li>
</ol>
<p><br /><br /></p>
<h2>Como coletamos os dados</h2>
<ul>
<li>Atrav&eacute;s dos rastreadores e cookies dos servi&ccedil;os de marketing e SEO da <strong>Google</strong>. Estas ferramentas coletam dados an&ocirc;nimos como a sua localiza&ccedil;&atilde;o, seu IP, rastreia a navega&ccedil;&atilde;o e analisa o seu comportamento em nosso site a fim de nos fornecer relat&oacute;rios sobre os servi&ccedil;os e produtos que voc&ecirc; procurou e qual a origem da sua visita; pesquisa do Google, acesso direto ou link existente em outro site, a <strong>Web Reports</strong> respeita a <a href="https://policies.google.com/privacy?hl=pt-BR" target="_blank" rel="noopener">pol&iacute;tica de privacidade da Google</a>, para mais informa&ccedil;&otilde;es leia a Pol&iacute;tica diretamente no site da Google.</li>
</ul>
<p><br /><br /></p>
<h2>Consentimento ou Bloqueio de Cookies</h2>
<p>Para que os recursos de coleta de dados em nosso site funcione adequadamente &eacute; necess&aacute;rio o uso de cookies (pequenos arquivos de texto que podem definir prefer&ecirc;ncias). Os cookies n&atilde;o s&atilde;o programas, n&atilde;o roubam dados de seu computador e n&atilde;o colocam a sua navega&ccedil;&atilde;o em risco, no entanto, &eacute; de seu direito bloquear nossos cookies caso queira. Para saber como proceder, <a href="como-desativar-cookies-e-outros-rastreadores-em-seu-navegador/">acesse este tutorial passo a passo</a>.</p>
<p><br /><br /></p>
<h2>Seus Direitos</h2>
<p>Voc&ecirc; tem os seguintes direitos:</p>
<ul>
<li>O direito de bloquear qualquer tipo de rastreador e cookie gerado em nosso site de modo a n&atilde;o compartilhar nenhum tipo de informa&ccedil;&atilde;o sobre a sua conex&atilde;o e acesso ao nosso site.</li>
<li>O direito de nos pedir para atualizar qualquer informa&ccedil;&atilde;o pessoal incorreta de que temos sobre voc&ecirc;.</li>
<li>O direito de optar por sair de quaisquer meios de comunica&ccedil;&atilde;o comercial e de marketing.</li>
<li>O direito de pedir a remo&ccedil;&atilde;o de qualquer dado pessoal que tenhamos armazenado sobre voc&ecirc;.</li>
</ul>
<p>Reservamos o prazo de 5 dias &uacute;teis para lhe responder sobre qualquer contato referente aos seus dados pessoais, podendo este prazo ser estendido em per&iacute;odo de festas, feriados prolongados, recesso e f&eacute;rias coletivas.</p>
<p style="text-align: right;"><br /><em> Esta pol&iacute;tica de Privacidade foi atualizada em 29/11/2021 as 21:58<em> </em></em></p>
         </div>
      
    </div>
  </div>

     
 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous" style=""></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
</body>

</html>


