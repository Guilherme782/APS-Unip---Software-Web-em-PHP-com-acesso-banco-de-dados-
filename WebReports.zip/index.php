<?php
require 'banco.php';
//Acompanha os erros de validação
$Erro = "";
    @$user=$_POST['usuario'];
    $senha="";
// Processar so quando tenha uma chamada post

if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $valida = true;
   
     if (!empty($_POST['senha'])) {
        $senha = $_POST['senha']; 
     }else{
         $Erro = "Digite a Senha!";
         $valida =false;
     }
    
     if (!empty($_POST['usuario'])) {
        $usuario = $_POST['usuario']; 
     }else{
         $Erro = "Digite o Usuário!!";
         $valida =false;
     }
    
    
    if($valida){
         if (!empty($_POST['usuario'])) {
                $user = $_POST['usuario'];  
                 
                $pdo = Banco::conectar();
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql =  'SELECT * FROM login WHERE Nick = "'.$user.'"';
                
                        foreach($pdo->query($sql)as $row)
                        {
                        $nk =  $row['Nick'];
                        $sh =  $row['senha'];
                        $id =  $row['Usuario_idUsuario'];      
                        $st =  $row['qd_login'];
                        }

                if(@$nk==$user){
                     if(@$sh==$senha){
                            if(@$st=="ativo"){
                                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                $sql =  'SELECT * FROM usuario WHERE idUsuario = "'.$id.'"';
                
                                foreach($pdo->query($sql)as $row)
                                {
                                $_nome =  $row['nome'];
                                $_genero =  $row['genero'];
                                $_cpf =  $row['cpf'];
                                }

                                
                                
                                session_start();
                                $_SESSION['nick'] = $nk;
                                 $_SESSION['_id'] = $id;
                                 $_SESSION['_nome'] = $_nome;
                                 $_SESSION['_genero'] = $_genero;
                                 $_SESSION['_cpf'] = $_cpf;
                                
                                echo "<script>alert('Logado com Sucesso!');window.location.href = 'inicio.php';</script>";
                            }else{
                                $Erro = 'Conta Desativada!';
                                $valida =false;
                            }
                         
                     }else{
                         $Erro = 'O Senha incorreta!';
                         $valida =false;
                     }
                    
                }else{
                $Erro = 'O Usuário não existe!';
                $valida =false;
                }
             Banco::desconectar();
             

             
        } else {
            $Erro = 'O Usuário não pode ser Nulo!';
            $validacao = False;
        } 
    }

}


    session_start();
    @$u=$_SESSION['nick'];
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">

</head>

<body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <i class="fa d-inline fa-lg fa-stop-circle"></i>
        <b> WEB REPORTS</b>
      </a> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar10">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar10">
        <ul class="navbar-nav ml-auto">
          <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="inicio.php">Painel</a> </li>';}?>
          <li class="nav-item"> <a class="nav-link" href="index.php">Inicio</a> </li>
          <li class="nav-item"> <a class="nav-link" href="politica.php">Politica</a> </li>
          <li class="nav-item"> <a class="nav-link" href="parceiros.php">Parceiros</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contato.php">Contato</a> </li>
         <?php  if(@$u){echo '<li class="nav-item"> <a class="nav-link" href="destroi.php">Sair</a> </li>';}?>
        </ul> <a class="btn navbar-btn ml-md-2 text-body btn-info" href="ajudar.php">Ajudar</a>
      </div>
    </div>
  </nav>
  <div class="py-0" >
    <div class="container-fluid" >
      <div class="row text-center" style="	background-image: url(&quot;banner2.jpg&quot;);	background-position: left center;	background-size: 100%;	background-repeat: no-repeat;" >
        <div class="text-center p-5 col-lg-5" style="height: 600px">
          <h1 >Você não está sozinha</h1>
          <p class="mb-4">Te convido a conhecer uma comunidade anônima <br>que irá te ajudar a superar e denunciar.</p>

            <form class="form-horizontal" action="index.php" method="post">
            <div class="form-group">
                <input type="text" value="<?php echo @$user; ?>" class="form-control" name="usuario"  placeholder="Digite seu Usuário">
             </div>
            <div class="form-group">
                <input type="password" class="form-control" name="senha" placeholder="Digite sua Senha" > 
                <small class="form-text text-muted text-left">
                <a href="recuperar.php">Esqueceu sua senha?</a>
              </small>
            </div> 
             <button type="submit" class="btn btn-primary">Logar</button>
          </form><br><br>

   <a href="cadastro.php"><button type="button" class="btn btn-secondary mx-3" >
  Eu Quero me Cadastrar
       </button></a>
           <br><br><font color="red" size="5"> <?php echo $Erro;?></font>
         </div>
      </div>
    </div>
  </div>

  
    
    
    
    
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous" style=""></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
</body>

</html>